var searchData=
[
  ['directprocessor_63',['DirectProcessor',['../classace__utils_1_1cli_1_1DirectProcessor.html',1,'ace_utils::cli']]],
  ['directprocessormanager_64',['DirectProcessorManager',['../classace__utils_1_1cli_1_1DirectProcessorManager.html',1,'ace_utils::cli']]]
];
